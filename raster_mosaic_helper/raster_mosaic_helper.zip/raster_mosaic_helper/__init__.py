from .mosaic_helper import MosaicHelper

def classFactory(iface):
    return MosaicHelper(iface)
